// You need to create the file arduino_secrets.h with the wifi credentials
//
const int networks_num = 6;    //number of total networks that you want to connect the nodemcu
const String networks_ssid[] = {
    "emma",
    "wHUAWEI-207A",
    "unaviable",
    "MIWIFI_AMP6",
    "iPhone de Ana",
    "NUEVA WIFI"
};

const String networks_pass[] = {
    "emguco9910",
    "3YRRE1J404R",
    "rastabuda8220",
    "QhXc4Qer",
    "martinahermosa",
    "NUEVO PASS"
};