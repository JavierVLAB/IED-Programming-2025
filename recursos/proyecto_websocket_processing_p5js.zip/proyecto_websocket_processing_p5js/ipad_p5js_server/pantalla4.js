function pantalla4() {
  background(255);
  textAlign(CENTER, CENTER);
  textSize(32);
  fill(0);
  text("Pantalla 4", width / 2, height / 2);
  circle(mouseX, mouseY, 20);
}
