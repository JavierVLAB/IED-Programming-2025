function pantalla3() {
  background(255);
  textAlign(CENTER, CENTER);
  textSize(32);
  fill(0);
  text("Pantalla 3", width / 2, height / 2);
}
