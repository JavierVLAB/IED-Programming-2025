function pantalla1() {
  background(255);
  textAlign(CENTER, CENTER);
  textSize(32);
  fill(0);
  text("Pantalla 1", width / 2, height / 2);
}
