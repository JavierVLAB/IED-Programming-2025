function pantalla2() {
  background(255);
  textAlign(CENTER, CENTER);
  textSize(32);
  fill(0);
  text("Pantalla 2", width / 2, height / 2);
}
